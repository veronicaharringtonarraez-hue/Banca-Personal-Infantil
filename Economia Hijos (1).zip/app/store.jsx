/* ============================================================
   Banco Crece — Store (estado + localStorage)
   ============================================================ */
const STORE_KEY = "bancoCrece.v1";

function freshMonth() {
  return { income: 0, paid: {}, diezmoPaid: 0, ahorroDone: 0 };
}

function freshChild() {
  return { balance: 0, savings: 0, months: {}, tx: [], badges: {} };
}

function defaultState() {
  const data = {};
  BC.CHILDREN.forEach((c) => (data[c.id] = freshChild()));
  return {
    pin: BC.DEFAULT_PIN,
    goals: {
      taylor: { name: "Una bicicleta nueva", target: 200, emoji: "🚲" },
      emmeth: { name: "Set de LEGO grande", target: 120, emoji: "🧱" },
      christopher: { name: "Juguete sorpresa", target: 60, emoji: "🎁" },
    },
    requests: [],
    data,
  };
}

function load() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return defaultState();
    const parsed = JSON.parse(raw);
    const base = defaultState();
    // merge defensivo
    base.pin = parsed.pin || base.pin;
    base.goals = Object.assign(base.goals, parsed.goals || {});
    base.requests = Array.isArray(parsed.requests) ? parsed.requests : [];
    BC.CHILDREN.forEach((c) => {
      if (parsed.data && parsed.data[c.id]) {
        base.data[c.id] = Object.assign(freshChild(), parsed.data[c.id]);
      }
    });
    return base;
  } catch (e) {
    return defaultState();
  }
}

const StoreContext = createContext(null);

function StoreProvider({ children }) {
  const [state, setState] = useState(load);

  useEffect(() => {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); } catch (e) {}
  }, [state]);

  // helper: asegura objeto del mes actual
  const ensureMonth = (child) => {
    const mk = BC.monthKey();
    if (!child.months[mk]) child.months[mk] = freshMonth();
    return mk;
  };

  const update = useCallback((childId, fn) => {
    setState((prev) => {
      const next = JSON.parse(JSON.stringify(prev));
      const child = next.data[childId];
      const mk = ensureMonth(child);
      fn(child, child.months[mk], mk);
      return next;
    });
  }, []);

  const log = (child, tx) => {
    child.tx.unshift(Object.assign({ id: Date.now() + "-" + Math.random().toString(36).slice(2, 7), ts: Date.now() }, tx));
    if (child.tx.length > 400) child.tx.length = 400;
  };

  const actions = {
    earn(childId, amount, label, cat = "trabajo", icon = "💪") {
      update(childId, (child, month) => {
        child.balance += amount;
        month.income += amount;
        log(child, { type: "income", amount, label, cat, icon });
      });
    },
    payBill(childId, expenseId) {
      const exp = BC.EXPENSES.find((e) => e.id === expenseId);
      const amount = exp[childId] || 0;
      let ok = false;
      update(childId, (child, month) => {
        if (month.paid[expenseId]) return;
        if (child.balance < amount) return;
        child.balance -= amount;
        month.paid[expenseId] = true;
        log(child, { type: "expense", amount, label: exp.label, cat: exp.id, icon: exp.icon });
        ok = true;
      });
      return ok;
    },
    payDiezmo(childId) {
      let ok = false;
      update(childId, (child, month) => {
        const due = Math.round(month.income * 0.10);
        const remaining = due - month.diezmoPaid;
        if (remaining <= 0) return;
        const pay = Math.min(remaining, child.balance);
        if (pay <= 0) return;
        child.balance -= pay;
        month.diezmoPaid += pay;
        log(child, { type: "expense", amount: pay, label: "Diezmo", cat: "diezmo", icon: "⛪" });
        ok = true;
      });
      return ok;
    },
    saveToGoal(childId, amount) {
      let ok = false;
      update(childId, (child, month) => {
        if (amount <= 0 || child.balance < amount) return;
        child.balance -= amount;
        child.savings += amount;
        month.ahorroDone += amount;
        log(child, { type: "saving", amount, label: "Ahorro a mi meta", cat: "ahorro", icon: "🐷" });
        ok = true;
      });
      return ok;
    },
    withdrawSavings(childId, amount) {
      let ok = false;
      update(childId, (child) => {
        if (amount <= 0 || child.savings < amount) return;
        child.savings -= amount;
        child.balance += amount;
        log(child, { type: "income", amount, label: "Retiro de ahorro", cat: "ahorro", icon: "🐷" });
        ok = true;
      });
      return ok;
    },
    adjust(childId, amount, label) {
      update(childId, (child, month) => {
        child.balance += amount;
        if (amount > 0) month.income += amount;
        log(child, {
          type: amount >= 0 ? "income" : "expense",
          amount: Math.abs(amount),
          label: label || (amount >= 0 ? "Ajuste (+)" : "Ajuste (-)"),
          cat: "ajuste",
          icon: amount >= 0 ? "✨" : "➖",
        });
      });
    },
    setGoal(childId, goal) {
      setState((prev) => {
        const next = JSON.parse(JSON.stringify(prev));
        next.goals[childId] = Object.assign({}, next.goals[childId], goal);
        return next;
      });
    },
    setPin(pin) {
      setState((prev) => Object.assign({}, prev, { pin }));
    },
    unlockBadge(childId, badgeId) {
      setState((prev) => {
        if (prev.data[childId].badges && prev.data[childId].badges[badgeId]) return prev;
        const next = JSON.parse(JSON.stringify(prev));
        if (!next.data[childId].badges) next.data[childId].badges = {};
        next.data[childId].badges[badgeId] = Date.now();
        return next;
      });
    },
    submitRequest(childId, items, total) {
      setState((prev) => {
        const next = JSON.parse(JSON.stringify(prev));
        next.requests.unshift({
          id: Date.now() + "-" + Math.random().toString(36).slice(2, 7),
          childId, items, total, ts: Date.now(),
        });
        return next;
      });
    },
    approveRequest(reqId) {
      setState((prev) => {
        const next = JSON.parse(JSON.stringify(prev));
        const req = next.requests.find((r) => r.id === reqId);
        if (!req) return next;
        const child = next.data[req.childId];
        const mk = BC.monthKey();
        if (!child.months[mk]) child.months[mk] = freshMonth();
        const month = child.months[mk];
        req.items.forEach((i) => {
          child.balance += i.subtotal;
          month.income += i.subtotal;
          child.tx.unshift({
            id: Date.now() + "-" + Math.random().toString(36).slice(2, 7), ts: Date.now(),
            type: "income", amount: i.subtotal, label: i.label, cat: i.cat, icon: i.icon,
          });
        });
        next.requests = next.requests.filter((r) => r.id !== reqId);
        return next;
      });
    },
    rejectRequest(reqId) {
      setState((prev) => {
        const next = JSON.parse(JSON.stringify(prev));
        next.requests = next.requests.filter((r) => r.id !== reqId);
        return next;
      });
    },
    resetChildMonth(childId) {
      update(childId, (child, month, mk) => {
        child.months[mk] = freshMonth();
      });
    },
    resetAll() {
      if (typeof window !== "undefined") {
        localStorage.removeItem(STORE_KEY);
      }
      setState(defaultState());
    },
  };

  return React.createElement(StoreContext.Provider, { value: { state, actions } }, children);
}

function useStore() {
  return useContext(StoreContext);
}

// Selectores / cálculos
function childMonth(state, childId) {
  const mk = BC.monthKey();
  return (state.data[childId].months[mk]) || freshMonth();
}

function childSummary(state, childId) {
  const child = state.data[childId];
  const month = childMonth(state, childId);
  const fixedTotal = BC.fixedTotal(childId);
  const fixedPaid = BC.EXPENSES.reduce((s, e) => s + (month.paid[e.id] ? (e[childId] || 0) : 0), 0);
  const diezmoDue = Math.round(month.income * 0.10);
  const ahorroGoal = Math.round(month.income * 0.10);
  return {
    balance: child.balance,
    savings: child.savings,
    income: month.income,
    fixedTotal,
    fixedPaid,
    fixedPending: fixedTotal - fixedPaid,
    billsPaidCount: BC.EXPENSES.filter((e) => month.paid[e.id]).length,
    billsTotalCount: BC.EXPENSES.length,
    diezmoDue,
    diezmoPaid: month.diezmoPaid,
    diezmoPending: Math.max(0, diezmoDue - month.diezmoPaid),
    ahorroGoal,
    ahorroDone: month.ahorroDone,
  };
}

Object.assign(window, { StoreProvider, useStore, StoreContext, childMonth, childSummary });
